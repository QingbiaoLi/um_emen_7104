"""Build standalone teaching notebooks from the shared, tested Python sources."""

import ast
import base64
import hashlib
import io
from pathlib import Path
import re
import zipfile

import nbformat as nbf

ROOT = Path(__file__).resolve().parent


def function_sources(filename):
    source = (ROOT / filename).read_text()
    lines = source.splitlines()
    return {node.name: "\n".join(lines[node.lineno - 1:node.end_lineno])
            for node in ast.parse(source).body
            if isinstance(node, (ast.FunctionDef, ast.ClassDef))}


def build(student):
    kind = "student" if student else "instructor"
    notebook = nbf.v4.new_notebook()
    notebook.metadata = {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {"name": "python", "version": "3.12"},
        "colab": {"name": f"humanoid_rnn_{kind}.ipynb", "provenance": []},
    }
    cells = notebook.cells

    def md(source):
        cells.append(nbf.v4.new_markdown_cell(source.strip()))

    def code(source, cell_id, collapsed=False):
        cell = nbf.v4.new_code_cell(source.strip())
        cell.id = cell_id
        if collapsed:
            cell.metadata.update({"jupyter": {"source_hidden": True}, "cellView": "form"})
        cells.append(cell)

    title = "学生填空版" if student else "教师完整可执行版"
    md(f"""# RNN 人形机器人轨迹预测 · {title}

EMEN 7029 / 7104 · PyTorch · PHUMA / Unitree G1

**任务：输入 20 个历史 XY 位置，预测未来 10 个位置（1 秒）。**
采用开源 PHUMA 的 G1 行走子集，手写 Elman RNN 和门控 RNN，对比匀速基线。
这是机器人**参考动作**的二维根节点预测，不是实机执行日志或全身控制。

上传本 notebook 到 [Google Colab](https://colab.research.google.com/)，使用 Python 3 CPU runtime。
数据和公共代码均已内置，单独一个 notebook 即可运行；无需账号下载数据。
本地建议 Python 3.12 + Jupyter。运行会在当前目录创建 `humanoid_rnn_workspace/`。

{"完成下列 13 个 TODO，然后从上到下运行。无需改动公共代码。留空处会主动报 NotImplementedError。" if student else "从上到下运行所有单元即可重新训练。已保存输出来自实际 CPU 执行，运行不依赖这些输出。"}

参考附件采用“任务说明 → TODO → 绘图验证 → 泛化分析”的形式，这里延续该教学组织。
""")
    md("""## 0. 环境

默认在 CPU 上训练小模型。库已安装时此单元不会联网；缺失时自动安装。
完整实验每个模型训练 100 epochs，时间随机器而异。
""")
    code('''import importlib.util
import os
from pathlib import Path
import subprocess
import sys

requirements = {"numpy": "numpy>=1.26,<3", "torch": "torch>=2.2,<3",
                "matplotlib": "matplotlib>=3.8,<4"}
missing = [spec for name, spec in requirements.items()
           if importlib.util.find_spec(name) is None]
if missing:
    subprocess.check_call([sys.executable, "-m", "pip", "install", *missing])
ROOT = Path.cwd() / "humanoid_rnn_workspace"
ROOT.mkdir(exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".mplconfig"))
os.environ.setdefault("XDG_CACHE_HOME", str(ROOT / ".cache"))
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from IPython.display import Image, Markdown, display
torch.set_default_dtype(torch.float32)
print("Python:", sys.version.split()[0], "PyTorch:", torch.__version__, "NumPy:", np.__version__)
print("Workspace:", ROOT)''', "environment")

    md((ROOT / "DATASETS_zh.md").read_text().replace("# 数据集选择与任务边界", "## 1. 数据选择与任务边界", 1)
       + "\n\n下面的折叠单元仅解包公开数据、来源清单及许可文本，不包含模型答案。无需编辑。")
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted((ROOT / "data").rglob("*")):
            if path.is_file() and "raw_cache" not in path.parts:
                archive.write(path, str(path.relative_to(ROOT)))
    payload = stream.getvalue()
    encoded = base64.b64encode(payload).decode()
    digest = hashlib.sha256(payload).hexdigest()
    code(f'''# @title Restore the bundled public motion subset and provenance
import base64
import hashlib
import io
import json
import zipfile

DATA_B64 = "{encoded}"
archive_bytes = base64.b64decode(DATA_B64)
assert hashlib.sha256(archive_bytes).hexdigest() == "{digest}"
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
    for name in archive.namelist():
        destination = (ROOT / name).resolve()
        if not destination.is_relative_to(ROOT.resolve()):
            raise ValueError("Unsafe archive path")
        content = archive.read(name)
        if destination.exists() and destination.read_bytes() != content:
            raise FileExistsError(f"Existing file differs: {{destination}}; use a new workspace")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(content)
DATA = ROOT / "data" / "phuma_g1_walking.npz"
manifest = json.loads((DATA.parent / "manifest.json").read_text())
assert hashlib.sha256(DATA.read_bytes()).hexdigest() == manifest["sha256_npz"]
print("Data:", manifest["dataset"], manifest["robot"])
print("Sequences / source groups / frames:", manifest["num_sequences"],
      manifest["num_source_groups"], manifest["frames_10hz"])
print("Revision:", manifest["revision"])
del DATA_B64, archive_bytes''', "bundled-data", collapsed=True)

    assignment = (ROOT / "ASSIGNMENT_zh.md").read_text()
    intro, tasks = assignment.split("## A.", 1)
    md(intro.replace("# 用 RNN 预测人形机器人未来轨迹（100 分）", "## 2. 模型设计与评分", 1))
    md("""## 3. 公共实验代码（已提供）

流程：按源动作划分 → 各片段内滑窗 → 训练集标准化 → 历史匀速基线 →
RNN 残差预测 → 验证 ADE 选模型 → 最后测试。

以下函数负责实验基础设施；学生只需完成后面的模型与训练函数。
公共训练组织函数会调用你实现的 `train_one_epoch`，不会绕过它。
""")
    utils = (ROOT / "trajectory_utils.py").read_text()
    utils = utils.replace('ROOT = Path(__file__).resolve().parent',
                          'ROOT = Path.cwd() / "humanoid_rnn_workspace"')
    code(utils, "provided-infrastructure", collapsed=True)
    code('''tracks, provenance = read_tracks(DATA)
splits = split_tracks(tracks, seed=42, minimum_length=30)
for name, ids in splits.items():
    observed, future, _ = make_windows(tracks, ids, 20, 10, 2)
    print(name, "source recordings:", len(ids), "windows:", len(observed),
          "history:", tuple(observed.shape), "future:", tuple(future.shape))
assert not (set(splits["train"]) & set(splits["test"]))
assert not (set(splits["val"]) & set(splits["test"]))
assert not (set(splits["train"]) & set(splits["val"]))

# Only a training trajectory is used for this preliminary data visualization.
import matplotlib.pyplot as plt
observed, future, _ = make_windows(tracks, splits["train"], 20, 10, 2)
fig, ax = plt.subplots(figsize=(6, 4))
ax.plot(observed[0, :, 0], observed[0, :, 1], "o-", label="Observed: -1.9 to 0 s")
connected = torch.cat((observed[0, -1:], future[0]))
ax.plot(connected[:, 0], connected[:, 1], "o-", label="Future: +0.1 to +1.0 s")
ax.set(xlabel="Root x (m)", ylabel="Root y (m)", title="PHUMA G1: one training window")
ax.axis("equal")
ax.legend()
ax.grid(alpha=0.2)
fig.tight_layout()
example_path = ROOT / "training_example.png"
fig.savefig(example_path, dpi=140)
plt.close(fig)
display(Image(filename=str(example_path)))''', "inspect-data")

    sections = re.split(r"(?=^## [A-H]\.)", "## A." + tasks, flags=re.M)
    descriptions = {s[3]: s.strip() for s in sections if s.startswith("## ")}
    sources = function_sources(f"{kind if student else 'solution'}.py")
    ordered = [("A", "make_features"), ("B", "ElmanRNN"), ("C", "scan"),
               ("D", "predict"), ("E", "train_one_epoch"),
               ("F", "displacement_errors"), ("G", "MyRNN")]
    for letter, name in ordered:
        md(descriptions[letter])
        code(sources[name], f"task-{name.lower()}")

    md("""## 4. 实现检查

先完成 A–F 可设 `MODELS="elman"`；完成 G 后设 `MODELS="both"`。
公开检查覆盖物理单位、形状、梯度跨时间传播、独立 batch、训练能否下降及数据隔离。
此处的人工小张量仅用于检查函数正确性；后续训练和测试均使用 PHUMA。
""")
    code('''MODELS = "both"  # "elman", "gated", or "both"
EPOCHS = 100
DEVICE = "cpu"  # Set "cuda" only with a GPU runtime.
''', "experiment-settings")
    check_source = function_sources("check_assignment.py")["check"]
    code(check_source + '''

from types import SimpleNamespace
implementation = SimpleNamespace(make_features=make_features, ElmanRNN=ElmanRNN,
    MyRNN=MyRNN, scan=scan, predict=predict, train_one_epoch=train_one_epoch,
    displacement_errors=displacement_errors)
assert MODELS in ("both", "elman", "gated")
for model_name in (["elman", "gated"] if MODELS == "both" else [MODELS]):
    check(implementation, model_name)''', "public-checks", collapsed=True)
    md("""## 5. 从头训练与最终评估

默认 100 epochs。两个模型都从零输出头开始，相同基线和输入，分别依据验证集选 checkpoint。
测试指标只在训练及模型选择结束后计算。不要根据测试表现反复选择超参数。
每次重跑本单元创建新输出目录，不覆盖旧实验。
""")
    code('''from datetime import datetime
RUN = ROOT / "outputs" / datetime.now().strftime("run_%Y%m%d_%H%M%S_%f")
run_experiment({"elman": ElmanRNN, "gated": MyRNN}, make_features,
    predict, train_one_epoch, displacement_errors,
    argv=["--data", str(DATA), "--output", str(RUN), "--epochs", str(EPOCHS),
          "--model", MODELS, "--device", DEVICE, "--seed", "42"])
report = json.loads((RUN / "metrics.json").read_text())''', "train-and-evaluate")
    code('''table = "| Model | Test ADE (m) | Test FDE (m) | Macro-source ADE (m) |\\n"
table += "| --- | ---: | ---: | ---: |\\n"
for name, metric in report["test"].items():
    macro = report["test_macro_source"][name]["ADE_m"]
    table += f"| {name} | {metric['ADE_m']:.4f} | {metric['FDE_m']:.4f} | {macro:.4f} |\\n"
display(Markdown(table))
for name in report["models"]:
    gain = 100 * (1 - report["test"][name]["ADE_m"] / report["test"]["constant_velocity"]["ADE_m"])
    print(f"{name}: ADE reduction versus CV = {gain:.1f}%")
for filename in ("learning_curves.png", "trajectories.png", "error_by_horizon.png"):
    display(Image(filename=str(RUN / filename)))''', "results")

    md("""## 6. 单条历史的推理与保存

下面只把一个测试窗口的 **20 个历史点** 送给模型，并加回最后观测位置，生成 `(10,2)` 的绝对位置。
模型类型按验证 ADE 选择，不使用测试误差选择。`forecast_history` 也可接收同坐标系、米制、10 Hz 的自有历史。
加载的 checkpoint 为本 notebook 刚训练的文件，包含训练集标准化参数。
""")
    code('''@torch.no_grad()
def forecast_history(history, checkpoint_path):
    saved = torch.load(checkpoint_path, map_location="cpu", weights_only=True)
    config = saved["config"]
    history = torch.as_tensor(history, dtype=torch.float32)
    if history.shape != (config["obs_len"], 2) or not torch.isfinite(history).all():
        raise ValueError(f"Expected finite ({config['obs_len']}, 2) history")
    model = {"elman": ElmanRNN, "gated": MyRNN}[saved["model"]](
        4, config["hidden"], 2 * config["pred_len"])
    model.load_state_dict(saved["state_dict"])
    model.eval()
    history = history[None]
    features = (make_features(history, saved["dt"]) - saved["mean"]) / saved["std"]
    baseline = constant_velocity(history, config["pred_len"], saved["dt"])
    relative = predict(model, features, baseline, saved["output_scale"])
    return (relative + history[:, -1:])[0].numpy()

selected_model = min(report["models"], key=lambda n: report["models"][n]["val_ADE_m"])
with np.load(RUN / "test_predictions.npz", allow_pickle=False) as saved_predictions:
    history = saved_predictions["observed"][0].copy()
    expected = saved_predictions[selected_model + "_relative"][0] + history[-1]
forecast = forecast_history(history, RUN / f"{selected_model}_best.pt")
np.testing.assert_allclose(forecast, expected, atol=1e-5, rtol=1e-5)
np.save(RUN / "example_history.npy", history)
np.save(RUN / "example_forecast.npy", forecast)
print("Selected by validation:", selected_model, "forecast shape:", forecast.shape)
print("Future absolute XY positions (meters):\\n", forecast)
print("Outputs:", RUN)''', "inference")
    md(descriptions["H"])
    md("""### 作答区

1. 为什么需要按源动作划分，而不能先滑窗再随机划分？
2. 训练集归一化与仅用历史构造速度分别避免什么信息泄漏？
3. 对比两个 RNN 与匀速基线的 ADE / FDE，解释差异。
4. 选一个误差较大的测试案例，讨论停止、转向或动作意图对预测的影响。
5. 说明数据来源与本实验结果不能直接迁移到哪些实际任务。

请在此填写分析。""")
    if not student:
        md("""### 教师参考讨论

固定 seed=42 的参考运行：CV ADE/FDE=0.1842/0.3754 m；Elman=0.1146/0.2392 m；
门控=0.1192/0.2444 m。以本次实际输出为准。小数据下更复杂的门控不必更好，
可讨论参数量、过拟合和验证曲线，但不能从一次运行推断架构普遍优劣。
轨迹短期趋势可由历史速度推断，RNN 学习偏离匀速的规律；没有动作意图时，转向和停步存在不确定性。
重叠窗口随机拆分会让高度相似的片段同时进入训练与测试；先按源动作分组能减少这一问题。
参考动作经过上游处理，缺少在线传感噪声和控制闭环，不能把误差直接解释为实机导航性能。
""")
    nbf.validate(notebook)
    path = ROOT / f"humanoid_rnn_{kind}.ipynb"
    nbf.write(notebook, path)
    print(path.name, "cells:", len(cells), "bytes:", path.stat().st_size)


if __name__ == "__main__":
    build(student=False)
    build(student=True)
