# RNN 人形机器人轨迹预测教学包

**推荐入口：`humanoid_rnn_instructor.ipynb`（完整可执行版）和 `humanoid_rnn_student.ipynb`（学生填空版）。** 两份 notebook 均内置同一 PHUMA G1 数据子集与公共代码；单独上传一个 notebook 到 Colab 即可，不需要其他文件或 Kaggle/Hugging Face 账号。

## 运行

在 https://colab.research.google.com/ 选择“上传笔记本”，上传对应 `.ipynb`，使用 Python 3 CPU runtime，按顺序运行全部单元。第一单元只在必要库缺失时安装依赖。学生版应先完成 13 个 TODO，再运行检查和训练单元；原始留空版抛出 `NotImplementedError` 是有意的。

本地 Jupyter：建议 Python 3.12，执行 `python -m pip install -r requirements-notebook.txt`，再用 `jupyter notebook` 打开 notebook。运行时在当前目录下创建 `humanoid_rnn_workspace/`，每次训练建立独立输出目录。教师 notebook 保留一次真实执行的图表和输出，重新运行会从头训练，不依赖已保存权重。

脚本入口也保留：

```bash
python -m pip install -r requirements.txt
python check_assignment.py --module solution
python solution.py --epochs 100 --output outputs/new_run
# 学生完成 student.py 后：
python check_assignment.py --module student
python student.py --epochs 100 --output outputs/student_run
```

## 模型与任务

输入 10 Hz 采样的 20 个历史 XY 点（时刻 -1.9 至 0 秒），预测 +0.1 至 +1.0 秒的 10 个 XY 点。特征为末帧中心化位置和有限差分速度 `(B,20,4)`；仅用训练集计算标准化参数。手写 Elman RNN 编码历史，最后隐状态一次输出 20 个坐标残差，修正历史位置拟合出的匀速预测。另提供手写 GRU 形式门控 RNN 对比。

默认：隐层 32、AdamW 学习率 0.001、batch 128、100 epochs、seed 42、MSE 损失、梯度裁剪 1.0。依据验证 ADE 选 checkpoint，最后评估测试集。训练/验证/测试按源动作分组，不能随机拆散重叠窗口。

## 已实际重跑的结果

Python 3.12、CPU、PyTorch 2.15.0、NumPy 2.5.4，完整 100 epochs：

| 模型 | 测试 ADE（米） | 测试 FDE（米） |
| --- | ---: | ---: |
| 保持最后位置 | 0.3554 | 0.6207 |
| 匀速基线 | 0.1842 | 0.3754 |
| Elman RNN + 匀速残差 | **0.1146** | **0.2392** |
| 门控 RNN + 匀速残差 | 0.1192 | 0.2444 |

Elman 的平均位移误差比匀速基线降低约 37.8%，未来 1 秒终点误差约 23.9 厘米。门控结构在本小数据集上没有优于 Elman，保留这一结果供学生分析。精度不是准确率；ADE 是未来各时刻的平均欧氏距离，FDE 是最后预测时刻的欧氏距离。

这是重定向参考动作上的短期二维预测结果，不能外推为实机导航精度。不同硬件和依赖可能产生数值差异。完整指标、逐源平均、训练记录和 checkpoint 见 `outputs/verified_cpu/`；教师 notebook 的独立执行结果见其输出单元。

## 文件说明

- `ASSIGNMENT_zh.md`：任务、公式、张量形状、100 分评分表、提交要求。
- `DATASETS_zh.md`：两个候选的核验、选择理由、版本、许可及任务边界。
- `solution.py` / `student.py`：对应的脚本版本；学生版无答案实现。
- `trajectory_utils.py`：公共分组划分、标准化、训练组织、保存与绘图。
- `check_assignment.py`：公开的形状、梯度、指标、训练和数据隔离检查。
- `predict.py`：从已训练 checkpoint 和历史 XY 位置生成未来绝对位置。
- `prepare_phuma.py`：从固定官方发布重新提取数据；课堂运行不需要执行。
- `build_notebooks.py` / `verify_notebooks.py`：教师维护工具，生成并验证两版 notebook 的对应关系与实际执行。
- `data/`：无 pickle 的轻量数据、逐文件来源清单与来源文档。

## 与附件的对应

工作区可见的附件是 `emen_7029_7104_2026_asg1_hw_torch.py`，其内容为线性/多项式回归作业。本材料沿用它的“先说明任务及分值、提供公共数据和绘图、关键步骤 TODO、要求独立测试泛化”的教学形式，将学习任务替换为时序轨迹预测。另沿用工作区已有 RNN 草稿中的 `f/g/initial_recurrent_state/scan` 接口，便于手写递归计算。

发给学生时可直接发送 `humanoid_rnn_student.ipynb`；完整学生 ZIP 同时包含说明、脚本、数据与公开检查，不含教师答案、权重或已执行教师 notebook。教师 ZIP 包含完整答案与已验证结果。
